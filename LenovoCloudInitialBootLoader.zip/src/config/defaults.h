#ifndef CONFIG_DEFAULTS_H
#define CONFIG_DEFAULTS_H

FILE_LICENCE ( GPL2_OR_LATER_OR_UBDL );

#define CONFIG_DEFAULTS(_platform) <config/defaults/_platform.h>

#include CONFIG_DEFAULTS(PLATFORM)

#endif /* CONFIG_DEFAULTS_H */
